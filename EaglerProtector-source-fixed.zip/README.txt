EaglerProtector — source project for Spigot/Bukkit 1.8.8

IMPORTANT:
- Eaglercraft 1.8.8 is a client, not the server plugin API. This project works only if the server backend supports Bukkit/Spigot 1.8.8 plugins.
- This ZIP contains Java source, not a compiled .jar. Build with Maven and Java 8; the resulting jar will be in target/EaglerProtector-1.0.0.jar.
- Test on a private/test server before installing on your live server and keep backups.

Features:
- /protector help
- /protector recipe
- /protector info
- /protector give (OP only)
- Crafting recipe: 8 cobblestone surrounding 1 diamond, producing a named furnace Protector.
- Placing the custom furnace item claims the whole chunk.
- Owner and operators with eaglerprotector.bypass can edit the chunk.
- Break/place and common container interactions are blocked for other players.
- Crafting tables remain usable.
- Break your own protector block to release the chunk.

Build:
1. Install Java 8 and Maven.
2. In this folder, run: mvn package
3. Put target/EaglerProtector-1.0.0.jar into the server's plugins folder.
4. Restart the server.
