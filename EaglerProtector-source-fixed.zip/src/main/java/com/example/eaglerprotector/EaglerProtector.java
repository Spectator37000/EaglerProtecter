package com.example.eaglerprotector;

import java.util.*;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.command.*;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

public class EaglerProtector extends JavaPlugin implements Listener {
    private final Map<String, UUID> claims = new HashMap<String, UUID>();
    private static final String ITEM_NAME = ChatColor.AQUA + "Chunk Protector";

    public void onEnable() {
        saveDefaultConfig();
        loadClaims();
        Bukkit.getPluginManager().registerEvents(this, this);
        ShapedRecipe recipe = new ShapedRecipe(makeProtector());
        recipe.shape("CCC", "CDC", "CCC");
        recipe.setIngredient('C', Material.COBBLESTONE);
        recipe.setIngredient('D', Material.DIAMOND);
        Bukkit.addRecipe(recipe);
        getLogger().info("EaglerProtector enabled.");
    }

    public void onDisable() { saveClaims(); }

    private String chunkKey(Location l) {
        return l.getWorld().getName() + ":" + (l.getBlockX() >> 4) + ":" + (l.getBlockZ() >> 4);
    }
    private String blockKey(Location l) {
        return l.getWorld().getName() + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }
    private boolean isProtector(ItemStack item) {
        if (item == null || item.getType() != Material.FURNACE || !item.hasItemMeta()) return false;
        ItemMeta meta = item.getItemMeta();
        return meta.hasDisplayName() && ITEM_NAME.equals(meta.getDisplayName());
    }
    private ItemStack makeProtector() {
        ItemStack item = new ItemStack(Material.FURNACE, 1);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ITEM_NAME);
        meta.setLore(Arrays.asList(ChatColor.GRAY + "Place to protect this chunk.", ChatColor.YELLOW + "Use /protector for help."));
        item.setItemMeta(meta);
        return item;
    }
    private void loadClaims() {
        ConfigurationSection section = getConfig().getConfigurationSection("claims");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            String owner = section.getString(key);
            try { claims.put(key, UUID.fromString(owner)); } catch (Exception ignored) {}
        }
    }
    private void saveClaims() {
        getConfig().set("claims", null);
        for (Map.Entry<String, UUID> e : claims.entrySet()) getConfig().set("claims." + e.getKey(), e.getValue().toString());
        saveConfig();
    }
    private UUID ownerAt(Location loc) { return claims.get(chunkKey(loc)); }
    private boolean mayEdit(Player p, Location loc) {
        if (p.hasPermission("eaglerprotector.bypass")) return true;
        UUID owner = ownerAt(loc);
        return owner == null || owner.equals(p.getUniqueId());
    }
    private void deny(Player p) {
        p.sendMessage(ChatColor.RED + "This chunk is protected by a Chunk Protector.");
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        ItemStack hand = e.getItemInHand();
        if (isProtector(hand)) {
            String key = chunkKey(e.getBlock().getLocation());
            if (claims.containsKey(key)) {
                e.setCancelled(true);
                p.sendMessage(ChatColor.RED + "This chunk already has a Protector.");
                return;
            }
            claims.put(key, p.getUniqueId());
            getConfig().set("protector-blocks." + blockKey(e.getBlock().getLocation()), true);
            saveClaims();
            p.sendMessage(ChatColor.GREEN + "Chunk protected! Only you and server admins can edit it.");
            return;
        }
        if (!mayEdit(p, e.getBlock().getLocation())) { e.setCancelled(true); deny(p); }
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        String bk = blockKey(e.getBlock().getLocation());
        if (getConfig().getBoolean("protector-blocks." + bk, false)) {
            String ck = chunkKey(e.getBlock().getLocation());
            UUID owner = claims.get(ck);
            if (owner != null && (owner.equals(p.getUniqueId()) || p.hasPermission("eaglerprotector.bypass"))) {
                claims.remove(ck);
                getConfig().set("protector-blocks." + bk, null);
                saveClaims();
                p.sendMessage(ChatColor.YELLOW + "Protector removed; this chunk is no longer protected.");
                return;
            }
            e.setCancelled(true); deny(p); return;
        }
        if (!mayEdit(p, e.getBlock().getLocation())) { e.setCancelled(true); deny(p); }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getClickedBlock() == null) return;
        Block b = e.getClickedBlock();
        Material type = b.getType();
        // Allow crafting tables and ordinary utility blocks, but protect storage/container access.
        if (type == Material.CHEST || type == Material.TRAPPED_CHEST || type == Material.HOPPER
            || type == Material.DISPENSER || type == Material.DROPPER || type == Material.FURNACE
            || type == Material.BREWING_STAND || type == Material.ENDER_CHEST) {
            if (!mayEdit(e.getPlayer(), b.getLocation())) { e.setCancelled(true); deny(e.getPlayer()); }
        }
        // A placed Protector is a furnace with a custom name; stop non-owners interacting with it.
        if (getConfig().getBoolean("protector-blocks." + blockKey(b.getLocation()), false)
            && !mayEdit(e.getPlayer(), b.getLocation())) {
            e.setCancelled(true); deny(e.getPlayer());
        }
    }

    @EventHandler
    public void onInventoryOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        Player p = (Player)e.getPlayer();
        InventoryHolder holder = e.getInventory().getHolder();
        Location loc = null;
        if (holder instanceof Chest) loc = ((Chest)holder).getLocation();
        else if (holder instanceof org.bukkit.block.Furnace) loc = ((org.bukkit.block.Furnace)holder).getLocation();
        else if (holder instanceof org.bukkit.block.Dispenser) loc = ((org.bukkit.block.Dispenser)holder).getLocation();
        else if (holder instanceof org.bukkit.block.Dropper) loc = ((org.bukkit.block.Dropper)holder).getLocation();
        else if (holder instanceof org.bukkit.block.BrewingStand) loc = ((org.bukkit.block.BrewingStand)holder).getLocation();
        else if (holder instanceof org.bukkit.block.Hopper) loc = ((org.bukkit.block.Hopper)holder).getLocation();
        else if (holder instanceof org.bukkit.block.EnderChest) loc = ((org.bukkit.block.EnderChest)holder).getLocation();
        if (loc != null && !mayEdit(p, loc)) { e.setCancelled(true); deny(p); }
    }

    @EventHandler
    public void onExplode(BlockExplodeEvent e) {
        Iterator<Block> it = e.blockList().iterator();
        while (it.hasNext()) if (ownerAt(it.next().getLocation()) != null) it.remove();
    }
    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        Iterator<Block> it = e.blockList().iterator();
        while (it.hasNext()) if (ownerAt(it.next().getLocation()) != null) it.remove();
    }

    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!command.getName().equalsIgnoreCase("protector")) return false;
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.AQUA + "=== Protector Help ===");
            sender.sendMessage(ChatColor.YELLOW + "/protector recipe " + ChatColor.WHITE + "- show the recipe");
            sender.sendMessage(ChatColor.YELLOW + "/protector info " + ChatColor.WHITE + "- see who owns this chunk");
            sender.sendMessage(ChatColor.YELLOW + "/protector give " + ChatColor.WHITE + "- get a Protector (OP only)");
            sender.sendMessage(ChatColor.GRAY + "Place a Protector to claim a chunk. Break your own Protector to unclaim it.");
            return true;
        }
        if (!(sender instanceof Player)) { sender.sendMessage("Players only."); return true; }
        Player p = (Player)sender;
        if (args[0].equalsIgnoreCase("recipe")) {
            p.sendMessage(ChatColor.AQUA + "Recipe: 8 cobblestone around 1 diamond; output is a Chunk Protector furnace.");
            return true;
        }
        if (args[0].equalsIgnoreCase("info")) {
            UUID owner = ownerAt(p.getLocation());
            p.sendMessage(owner == null ? ChatColor.GREEN + "This chunk is unprotected." :
                ChatColor.YELLOW + "This chunk is protected by " + Bukkit.getOfflinePlayer(owner).getName() + ".");
            return true;
        }
        if (args[0].equalsIgnoreCase("give")) {
            if (!p.isOp()) { p.sendMessage(ChatColor.RED + "Only server operators can use this command."); return true; }
            p.getInventory().addItem(makeProtector());
            p.sendMessage(ChatColor.GREEN + "You received a Chunk Protector.");
            return true;
        }
        p.sendMessage(ChatColor.RED + "Unknown subcommand. Use /protector help");
        return true;
    }
}
